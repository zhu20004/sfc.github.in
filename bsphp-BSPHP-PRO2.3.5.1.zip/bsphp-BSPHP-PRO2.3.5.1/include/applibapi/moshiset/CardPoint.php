<?php
return array(
'really'=> '1',//1=系统核心模式  2=第三方替补模式,类似钩子hook替代系统原来API。从而实现不修改系统文件达到改变！
'name'=> '卡串扣点模式  -  (充值卡/激活码直接登录,扣点归零到期)',//模式
'moshi'=> 'card',//模式 login 账号登录模式 card=卡串验证模式
'templates'=> 'CardPoint',    //模板
'by'=> 'BSPHP团队',           //模式开发者
'card'=> 'pint',           //充值卡充值方式 pint=点模式充值  date=时间模式充值
'info'=> '这个模式是传统验证系统计费模式,比如包月指定日期过期,就算不使用软件也会计费！就像QQ会员包月一样！',           //模式开发者
'vdo'=> 'http://www.bsphp.com',//模式视频说明地址
);
?>