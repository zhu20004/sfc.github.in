<?php


/***********************接口介绍说明******************************************
* timeoutupdate.lg
* 超时更新
* <sen>1<sen/>                
* <seng1>key=>绑定特征</seng>
* <lei>ok</lei>               
* <info>绑定特征</info> 
* *****************************************************************************
*/

//oid Login file
//oid links file

$daihao = PLUG_DAIHAO();
$uid = Plug_Get_Session_Value('USER_UID');
$BSphpSeSsL = Plug_Set_Data('BSphpSeSsL');


            $sql = "SELECT * FROM`bs_php_pattern_login` WHERE  `L_User_uid`='$uid' AND`L_daihao`='$daihao'  ORDER BY`L_id`DESC LIMIT 1000";
            $param_db_array_value = Plug_Query($sql);
            $array = array();
            while ($param_value= mysqli_fetch_array($param_db_array_value ))
            {
                
                
                $array[]=array(
                   'id'=>$param_value['L_id'],
                   'User_uid'=>$param_value['L_User_uid'],
                   're_date'=>$param_value['L_re_date'],
                   'vip_unix'=>$param_value['L_vip_unix'],
                   'ic_name'=>$param_value['L_ic_name'],
                   'links_info'=>$param_value['L_links_info'],
                   'cardname'=>$param_value['L_ic_pwd'],
                   
                   
                   
                   
                );
                
                
                
            }
            
            
            
        $array = json_encode($array);

//一切正常
Plug_Echo_Info($array);

?>