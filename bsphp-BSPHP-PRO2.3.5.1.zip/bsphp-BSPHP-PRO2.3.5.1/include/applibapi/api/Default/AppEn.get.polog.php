<?php
	
     //登录连接数功能集代码
     links_chaoshi_login();
  $log = UserLoginInfo();
  $dataid=(int)Plug_Set_Data('dataid');
  if($dataid==0)$dataid='1';
  
  
  if ($log == 1047 || $log==1087) {
    
        
        $param_sql="SELECT * FROM `plug_bsphp_polog` WHERE `idname` = '$dataid'";
        $array=$this->intelligence_db->intelligence_Bsphp_my_array($param_sql);
        Plug_Echo_Info($array[1]);
    
    

  }else{
    
      Plug_Echo_Info($this->intelligence_user_str_log[$log]);
  }
  
    
    
?>