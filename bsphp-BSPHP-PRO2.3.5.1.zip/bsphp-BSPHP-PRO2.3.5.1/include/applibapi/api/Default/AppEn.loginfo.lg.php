<?php


/**
 * 
 * **********************接口介绍说明******************************************
 * loginfo.lg
 * 用户登录
 * *****************************************************************************
 */
#预设好文本字符串数组
$user_str_log = plug_load_langs_array('user', 'user_str_log');
$appen_str_log = plug_load_langs_array('applib', 'appen_str_log');


$daihao = PLUG_DAIHAO();
$user = Plug_Set_Data('user');
$user_pwd = Plug_Set_Data('pwd');
$key = Plug_Set_Data('key');
$maxoror = Plug_Set_Data('maxoror');

$img = Plug_Set_Data('img');
$BSphpSeSsL = Plug_Set_Data('BSphpSeSsL');


if (Plug_App_DaTa('app_MoShi') !== 'LoginTerm')
{
    //Plug_Echo_Info('1119'); //不对应的模式
    Plug_Echo_Info($user_str_log[1119]);
}




    $uid = Plug_Query_One('bs_php_user', 'user_user', $user, '`user_uid`');


    //建立登录限制
    $log = Plug_Login_Multi_Control($user, $daihao, $maxoror,$uid);
    if ($log != 5047)
        Plug_Echo_Info($this->intelligence_appen_str_log[$log]);


    //日志记录
    bs_lib::addappenlog('user_login_log', '软件登录', $user);
    /**
     * 更新登录模式下最后登陆日期
     */
    $date = HOST_DATE;
    $sql = "UPDATE`bs_php_pattern_login`SET`L_login_time`='$date'WHERE`bs_php_pattern_login`.`L_User_uid`='$uid'AND`bs_php_pattern_login`.`L_daihao`='$daihao';";
    Plug_Query($sql);

    // print_r(get_included_files());
    //查询是否注册使用过
    $arr = Plug_Get_App_User_Info($uid, $daihao);

    //没有使用过的话就给程序添加上

    if (!$arr)
    {


        $date = (int)Plug_App_DaTa('app_re_date'); //获取赠送时间
        
        
        
        
        $date = HOST_UNIX + $date;

        /*查询是否重复绑定*/
        if (call_my_login_key_zhong($daihao, $key) != false & Plug_App_DaTa('app_key_zhong') == 1)
            PrLog(5009); //'绑定特征码,已经有人绑定过了,不能重复绑定,不能登陆'
        if (call_my_Login_add_key($uid, $daihao, $date, $key, $user,$user))
        {
            PrLog(5008); //'欢迎你首次使用!,请重新登陆.'
        } else
        {
            Plug_Echo_Info('注册新用户失败,请联系管理员！');
        }

    }


    //获取用户信息赋值给变量
    $uesr_key = $arr['L_key_info'];
    $uesr_vipdate = $arr['L_vip_unix'];
    $login_info = null;
    if ($key == $uesr_key & $uesr_key != '' or Plug_App_DaTa('app_set')==0)
        $login_info = Plug_App_DaTa('app_logininfo');


    //链接数验证


    //$login_ssl = MD5($BSphpSeSsL);
    Plug_Links_Add_Info($uid, $user, $key, $daihao, $maxoror);


    //-----------------------------------------


    /**
     * 返回数据说明
     */
    if ($arr['L_vip_unix'] > HOST_UNIX)
    {
        //  Plug_Echo_Info('1|'.$arr['L_key_info'].'|'.Plug_App_data'app_logininfo']);
        //登陆成功  或者在免费使用


        if (Plug_App_DaTa('app_set') == 1)
        {


            if ($arr['L_key_info'] !== $key)
            {
                //注销登录
                Plug_Set_Session_Value('USER_UID', ''); //登陆UID
                Plug_Set_Session_Value('USER_YSE', ''); //登陆MD7加密
                Plug_Set_Session_Value('USER_DATE', ''); //上一次登陆时间
                Plug_Set_Session_Value('USER_IP', ''); //上一次登陆IP
                Plug_Set_Session_Value('USER_MD7', ''); //OOKIE MD7验证串
                $this->intelligence_session->intelligence_links_out_session_id($this->intelligence_session->intelligence_session_id);

               if($arr['L_key_info']=='')Plug_Echo_Info("还没有绑定,请绑定在登录");





                Plug_Echo_Info('[5035]'.$this->intelligence_appen_str_log[5035]);
                
            }
            
        }


        //---------------------------------------


        //链接数验证
        /*
        //判断限制登录模式   print_R($_SERVER);
        if (Plug_App_data'app_links_open'] == 2)
        {
        $login_ssl = MD5(Plug_Set_Data('maxoror'));

        } else
        {
        $login_ssl = MD5($BSphpSeSsL);
        }
        //获取cookies
        //$session=$BSphpSeSsL;
        */

        /*
        //添加在线标记
        $ture = links_Add($login_ssl, Plug_App_data'app_links'], $daihao, $uid, $user, Plug_App_data'app_links_chaoshi'], $key, $BSphpSeSsL, Plug_App_data'app_links_open']);
        //没有掉线添加新登录标记
        if ($ture != -1)
        {

        if (Plug_App_data'app_links_open'] == 1)
        {

        if (Plug_App_data'app_links'] > 1)
        {
        Plug_Echo_Info("账号同时登录数量已经到达上限！已登录连接数:{$ture}个");
        } elseif (Plug_App_data'app_links'] <= 0)
        {
        Plug_Echo_Info("最大登录数为零,软件已经禁止用户登录!");
        } else
        {
        Plug_Echo_Info("账号已经登录,不可重复登陆！");
        }


        } elseif (Plug_App_data'app_links_open'] == 2)
        {

        if (Plug_App_data'app_links'] > 1)
        {
        Plug_Echo_Info("账号同时登录机器使用已经到达上限！已登录机器数量:{$ture}台");
        } elseif (Plug_App_data'app_links'] <= 0)
        {
        Plug_Echo_Info("最大登录机器为零,软件已经禁止用户登录!");
        } else
        {
        Plug_Echo_Info("账号已在其它机器登录,不可重复登陆！");
        }


        }


        }

        */
        //-----------------------------------------
        //记录登录时间用做扣点
        $UNIX = HOST_UNIX;
        $sql = "UPDATE`bs_php_pattern_login`SET`L_timing`='$UNIX'WHERE`bs_php_pattern_login`.`L_User_uid`='$uid'AND`bs_php_pattern_login`.`L_daihao`='$daihao';";
        Plug_Query($sql);


        $uesr_vipdate = date('Y-m-d H:i:s', $uesr_vipdate);
        /**
         * 返回说明
         * 1.= 成功返回1
         * 2.= 登陆成功代号
         * 3.= 用户绑定key
         * 4.= 用户登陆成功返回特定数据
         * 5.= VIP到期时间
         */
        Plug_Echo_Info("01|1011|$uesr_key|$login_info|$uesr_vipdate|||||");
    } else
    {
        //Plug_Echo_Info("-1|9908|$uesr_vipdate||||||||");
        //$this->intelligence_session->intelligence_links_out_session_id($this->intelligence_session->intelligence_session_id);
        Plug_Echo_Info('9908');
    }



?>