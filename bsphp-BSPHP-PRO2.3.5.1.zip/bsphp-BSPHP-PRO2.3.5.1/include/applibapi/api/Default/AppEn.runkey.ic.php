<?php

$car_id = Plug_Set_Data('icid');

$daihao = PLUG_DAIHAO();

$carinfo = Plug_Get_Card_Info($car_id, '', $daihao);

$NEW_ID = gte_test_arr(16,0);
//添加绑定
$sql = "UPDATE`bs_php_pattern_login`SET`L_key_info`='$NEW_ID'  WHERE  `L_id`='{$carinfo['L_id']}';";
$tmp = Plug_Query($sql);

Plug_Echo_Info($NEW_ID);

?>