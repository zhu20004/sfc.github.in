<?php



/***********************鎺ュ彛浠嬬粛璇存槑******************************************
* gg.lg
* 鑾峰彇杞欢鐨勫叕鍛?/appname> 
* <sen>0<sen/>                
* <seng1>鍙傛暟=>鎺ユ敹鍐呭</seng>
* <lei>ok</lei>               
* <info>鑾峰彇杞欢鍏憡涓嶉渶瑕佷换浣曢獙璇?/info> 
* *****************************************************************************
*/


#预设好文本字符串数组
$user_str_log = plug_load_langs_array('user', 'user_str_log');
$appen_str_log = plug_load_langs_array('applib', 'appen_str_log');
$uid = Plug_Get_Session_Value('USER_UID');
$daihao = PLUG_DAIHAO();


//登录连接数功能集代码
//links_chaoshi_login();
//登陆状态
$log = Plug_User_Is_Login_Seesion();
if ($log != 1047)
    Plug_Echo_Info($user_str_log[$log]);

//获取用户信息
$arr = Plug_Get_App_User_Info($uid, $daihao);

Plug_Echo_Info(date('Y-m-d H:i:s', $arr['L_vip_unix']));


$date = Plug_Set_Data('datess');
$uid = Plug_Set_Data('uid');
$month = Plug_Set_Data('month');
$day = Plug_Set_Data('day');
$goodsid = Plug_Set_Data('goodsid');
$content = Plug_Set_Data('content');
$list = Plug_Set_Data('list');


if (empty($date)) {
    Plug_Echo_Info('invalid date');
}
if (empty($uid)) {
    Plug_Echo_Info('invalid uid');
}
if (empty($month)) {
    Plug_Echo_Info('invalid month');
}
if (empty($day)) {
    Plug_Echo_Info('invalid day');
}
if (empty($goodsid)) {
    Plug_Echo_Info('invalid goodsid');
}
if (empty($content)) {
    Plug_Echo_Info('invalid content');
}
if (empty($list)) {
    $list = 'list.txt';
}

/*
如果不放在根目录，修改如下路径
$path = createDir( '../' . $date . '/' . $uid . '/' . $month . '/' . $day );
*/
$path = createDir($date . '/' . $uid . '/' . $month . '/' . $day);
$noteFilename = $path . '/' . $goodsid . '.txt';
$listFilename = $path . '/' . $list;
$noteFilenameLength = file_put_contents($noteFilename, $content . PHP_EOL);
$listFilenameLength = file_put_contents($listFilename, $goodsid . ';',
    FILE_APPEND);
Plug_Echo_Info($noteFilenameLength . ',' . $listFilenameLength);


function createDir($path)
{
    $a = explode('/', $path);
    $n = count($a);

    if (is_dir($path)) {
        $filesCount = getFilesCount($path);
        if ($filesCount > 31998) {
            $endDirName = intval($a[$n - 1]);
            $endDirName++;
            $old_path = $path;
            $new_path = substr($old_path, 0, strlen($old_path) - strlen($endDirName)) . $endDirName;
            return createDir($new_path);
        }
        return $path;
    }
    $a = explode('/', $path);
    $n = count($a);
    for ($i = 0; $i < $n; $i++) {
        $s .= $a[$i] . '/';
        $dir = substr($s, 0, strlen($s) - 1);
        if (is_dir($dir))
            continue;

        if (!mkdir($dir)) {
            $endDirName = intval($a[$n - 1]);
            $endDirName++;
            $old_path = $path;
            $new_path = substr($old_path, 0, strlen($old_path) - strlen($endDirName)) . $endDirName;
            return createDir($new_path);
        }
    }
    return $path;
}
function getFilesCount($path)
{
    $handle = opendir($path);
    $i = 0;
    while (false !== $file = (readdir($handle))) {
        if ($file == '.' || '..' == $file)
            continue;
        $i++;
    }
    return $i;
}
function createFile($path, $content)
{
    $content_length = file_put_contents($filename, $content);
    if ($content_length < 100) {
        exit('文件创建失败');
    }
    return '/' . $filename;
}
?>