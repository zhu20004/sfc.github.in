<?php


/***********************接口介绍说明******************************************
* setpushdate.ic
* 解除绑定
* <sen>0<sen/>                
* <seng1></seng>
* <lei>ok</lei>               
* <info>解除绑定-卡模式</info> 
* *****************************************************************************
*/

   include (__HOST__.'include/AppEn.Car.php');
   //oid links file

    $newicid=Plug_Set_Data('newicid');
	
	
	
	if(Plug_Set_Data('icid')!=NULL){
		$car_id=Plug_Set_Data('icid');
        $car_pwd=Plug_Set_Data('icpwd');
	}else{
	    $car_id=Plug_Get_Session_Value('ic_carid');
        $car_pwd=Plug_Get_Session_Value('ic_pwd');
		
    //超时等T出更新
	links_chaoshi_car();
	
	}

    $daihao=PLUG_DAIHAO();

         
         
         //获取验证信息 COOKIE内之了
  	    $log=call_my_CarCookies($car_id,$car_pwd,$daihao);
        if($log==1080){
            
            //读取用户数据
            $Get_DaTa=GetInfo($car_id,$car_pwd,$daihao);
            
            
            
            








        }else{
         Plug_Echo_Info($this->intelligence_user_str_log[$log]);
        }










?>