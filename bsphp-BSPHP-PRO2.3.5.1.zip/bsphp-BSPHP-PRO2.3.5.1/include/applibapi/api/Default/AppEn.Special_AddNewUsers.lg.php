<?php


/***********************接口介绍说明******************************************
* timeoutupdate.lg
* 超时更新
* <sen>1<sen/>                
* <seng1>key=>绑定特征</seng>
* <lei>ok</lei>               
* <info>绑定特征</info> 
* *****************************************************************************
*/
#预设好文本字符串数组
$user_str_log = plug_load_langs_array('user', 'user_str_log');
$appen_str_log = plug_load_langs_array('applib', 'appen_str_log');
//oid Login file
//oid links file

$daihao = PLUG_DAIHAO();

$users = Plug_Set_Data('users');

if($users==''){
   $users = Plug_Get_Session_Value('USER_USER'); 
}

$BSphpSeSsL = Plug_Set_Data('BSphpSeSsL');
$cardid = Plug_Set_Data('cardid');
$cardpwd = Plug_Set_Data('cardpwd');
$key = Plug_Set_Data('key');


$log = call_my_Logincall_my_CarAddUsers($cardid,$cardpwd,$key,$daihao,$users);



//一切正常
Plug_Echo_Info($user_str_log[$log]);

?>