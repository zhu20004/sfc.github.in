<?php


/**
 * @代理 registration
 * 
 */
class carkey
{



    function __construct()
    {



        plug_session_open();

        if (plug_get_configs_value('sys', 'stop_agent') == 0) {
            echo '代理中心未开放，后台已经关闭代理中心';
            exit;
        }


        $USER_UID = plug_get_session_value('USER_UID'); //登陆UID
        $this->user_array = plug_query_array("SELECT * FROM `bs_php_user` WHERE `user_uid` LIKE '$USER_UID'");



        if (!$this->user_array) {
            echo '你没有登陆,请先登录。';
            exit;
        }


        //代理权限验证
        if ($this->user_array['user_daili'] == 0) {
            echo '你没有权限,请先登录。';
            exit;
        }
    }

    /**
     * @列表
     * url admin/index.php?m=Customized&c=Customized&a=table
     */
    function call_car()
    {




        $appenconfig = plug_set_post('appenconfig');
        $daihao = (int)plug_set_post('daihao');
        $user = plug_set_post('user');
        $key = plug_set_post('key');

        if ($appenconfig) {

            if ($daihao <= 0) {
                plug_print_json(array('code' => 1, 'msg' => call_my_Lang("请选择软件")));
            }

            if ($user == '') {
                plug_print_json(array('code' => 1, 'msg' => "请输入账户/卡"));
            }





            $sql = "SELECT * FROM  `bs_php_pattern_login` WHERE `L_daihao` =  '{$daihao}' AND `L_User_uid` =  '{$user}' LIMIT 1";
            $bsphp_pattern_login = plug_query_array($sql);
            
            if (!$bsphp_pattern_login) {
                plug_print_json(array('code' => 1, 'msg' => "帐户/卡号不存在"));
            }

            if ($bsphp_pattern_login['L_key_info'] == '' AND $key == '') {
                plug_print_json(array('code' => 1, 'msg' => "当前没有绑定,无需解绑."));
            }


            $sql = "UPDATE `bs_php_pattern_login` SET `L_key_info` = '{$key}' WHERE `L_id` = '{$bsphp_pattern_login['L_id']}';";
            $tmp = Plug_Query($sql);
            if($tmp){
                plug_print_json(array('code' => 1, 'msg' => "操作成功."));
            }else{
                plug_print_json(array('code' => 1, 'msg' => "操作失败."));
            }



        }





        $param_sql = "SELECT * FROM `bs_php_kalei`,`bs_php_appinfo` WHERE `lei_daili`> -1 and `bs_php_appinfo`.`app_daihao`=`bs_php_kalei`.`lei_daihao` ";
        $param_tmp = Plug_Query($param_sql);



        include plug_load_default_path();
    }
}
