<?php
function DaiLiUserLoginInfo()
{
return ($user_array);
}
?>