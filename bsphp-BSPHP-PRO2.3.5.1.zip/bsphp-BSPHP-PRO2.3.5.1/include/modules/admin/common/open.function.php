<?php
echo "1234";
exit;