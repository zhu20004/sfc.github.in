<?php
return array(
//网站路径
'logo_table' => '管理登录',  
'admin_info' => '管理平台',    
'admin_user' => '用户名', 
'admin_user_text' => '管理员账号',
'admin_pwd' => '密　码', 
'admin_pwd_text' => '登录密码', 
'admin_cood' => '安 全 码',  
'admin_cood_text' => '二级安全码', 
'intelligence_admin_login' => '登 录', 



);
?>