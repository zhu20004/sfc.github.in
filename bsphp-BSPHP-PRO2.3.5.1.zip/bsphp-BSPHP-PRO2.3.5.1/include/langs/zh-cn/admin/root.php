<?php
return array(
'admin_name' => '管理员:',  
'admin_date' => '当前时间:',    
'admin_cms_url' => '网站首页', 
'admin_agent_url' => '代理商平台',
'admin_user_url' => '用户前台', 
'admin_logut_url' => '退出', 

'admin_hard' => '快捷导航',


);
?>