<?php
	
    
    
return array(
'sys'=>'代理中心关闭提示',
);
    
    
    
    
    
    
?>