<?php
return array(
'sys' => '系统提示', 
'stop' => '用户中心暂时关闭,请稍后在进行访问谢谢！', 



);
?>