<?php
return array (
'day'=>'天',//天
'month'=>'月',//月
'years'=>'年',//年
'hours'=>'小时',//小时
'minutes'=>'分钟',//分钟
'seconds'=>'秒钟');//秒钟
?>