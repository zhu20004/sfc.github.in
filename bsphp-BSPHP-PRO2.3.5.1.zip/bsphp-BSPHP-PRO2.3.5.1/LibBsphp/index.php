<?php
header('HTTP/1.1 304 Not Modified');