<?php
defined('BSPHP_SET') or die('Not,This File Not Can in Ie Open');
function BsRun_Plug($Run_Name, $param)
{
}
?>