<?php
const BSPHP_SET='APPEN';
require ('LibBsphp/Global.Bsphp.Inc.php');
?>