
<li data-name="console" class="layui-nav-item layui-nav-itemed">
<a href="javascript:;" lay-href="index.php?m=agent&c=main&a=info" class="layui-this" lay-tips="中控台" lay-direction="0">
<i class="layui-icon layui-icon-home"></i>
<cite>中控台</cite>
</a>
</li>
<li data-name="get" class="layui-nav-item">
<a href="javascript:;" lay-href="index.php?m=agent&c=sp&a=table" lay-tips="卡管理" lay-direction="3">
<i class="layui-icon layui-icon-layouts"></i>
<cite>卡管理</cite>
</a>
</li>
<li data-name="get" class="layui-nav-item">
<a href="javascript:;" lay-href="index.php?m=agent&c=sp&a=add" lay-tips="余额制卡" lay-direction="5">
<i class="layui-icon layui-icon-cart-simple"></i>
<cite>余额制卡</cite>
</a>
</li>
<li data-name="get" class="layui-nav-item">
<a href="javascript:;" lay-href="index.php?m=agent&c=kuka&a=kuka_add" lay-tips="库存制卡" lay-direction="4">
<i class="layui-icon layui-icon-add-1"></i>
<cite>库存制卡</cite>
</a>
</li>
<li data-name="get" class="layui-nav-item">
<a href="javascript:;" lay-href="index.php?m=agent&c=sp&a=chong" lay-tips="余额充值" lay-direction="4">
<i class="layui-icon layui-icon-add-circle-fine"></i>
<cite>余额充值</cite>
</a>
</li>
<li data-name="home" class="layui-nav-item ">
<a href="javascript:;" lay-tips="我的代理" lay-direction="3">
<i class="layui-icon layui-icon-user"></i>
<cite>我的代理</cite>
</a>
<dl class="layui-nav-child">
<dd data-name="console" >
<a lay-href="index.php?m=agent&c=sp&a=dailiuser">我的代理列表</a>
</dd>
<dd data-name="console">
<a lay-href="index.php?m=agent&c=sp&a=useradd">添加新代理</a>
</dd>
</dl>
</li>
<li data-name="user" class="layui-nav-item">
<a href="javascript:;" lay-tips="财务管理" lay-direction="3">
<i class="layui-icon layui-icon-release"></i>
<cite>财务管理</cite>
</a>
<dl class="layui-nav-child">
<dd> <a lay-href="index.php?m=agent&c=carinfo&a=cardinfo">卡通过账号统计</a></dd>
<dd> <a lay-href="index.php?m=agent&c=carinfo&a=cardbeizhu">卡备注使用统计</a></dd>
<dd> <a lay-href="index.php?m=agent&c=carinfo&a=cardbeizhuinfo">卡账号备注统计</a></dd>
</dl>
</li>
<li data-name="user" class="layui-nav-item">
<a href="javascript:;" lay-tips="代理工具" lay-direction="3">
<i class="layui-icon layui-icon-star"></i>
<cite>代理工具</cite>
</a>
<dl class="layui-nav-child">
<dd> <a lay-href="index.php?m=agent&c=carinfo&a=socard">批量查询</a></dd>
<dd> <a lay-href="index.php?m=agent&c=carinfo&a=sdate_off">批量冻结</a></dd>
<dd> <a lay-href="index.php?m=agent&c=carinfo&a=sdate_on">批量解冻</a></dd>
<dd> <a lay-href="index.php?m=agent&c=carinfo&a=sdate_del">批量删除</a></dd>
</dl>
</li>
