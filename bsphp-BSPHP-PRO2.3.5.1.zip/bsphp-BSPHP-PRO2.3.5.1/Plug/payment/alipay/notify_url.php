<?php
require_once ('../../Plug.php');
require_once (plug_get_bsphp_dir() . 'include/modules/payment/paycood/alipay/notify_url.php');
?>