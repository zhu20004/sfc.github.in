<?php
const BSPHP_SET='NOTMODE';
require_once (__dir__.'/../LibBsphp/Global.Bsphp.Inc.php');
?>