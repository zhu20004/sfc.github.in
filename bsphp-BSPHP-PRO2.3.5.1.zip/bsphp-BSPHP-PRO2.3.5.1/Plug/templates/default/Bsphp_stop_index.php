<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf8" />
<title>系统维护关闭 - <?php echo Plug_Get_Configs_Value("sys","name") ?></title>
</head>
<body>
<?php echo Plug_Get_Configs_Value("sys","stop_info") ?> 模板Plug/templates/default/Bsphp_stop_index.php
</body>
</html>
