<?php

return array (
0=>'day',
1=>'month',
2=>'years',
3=>'hours',
4=>'minutes',
5=>'seconds');
?>
