<?php
 return array('pay_config'=>'','pay_tenpay_set'=>'1','pay_tenpay_key'=>'key007','pay_tenpay_user'=>'944463782','pay_post_config'=>'',);?>
