<?php
 return array('pay_config'=>'','pay_qr_set'=>'0','pay_qr_id'=>'222','pay_qr_key'=>'22222222222222','pay_post_config'=>'',);?>
