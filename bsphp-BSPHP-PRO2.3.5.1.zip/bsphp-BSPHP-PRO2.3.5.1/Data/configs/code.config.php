<?php
 return array('coode_login'=>'0','coode_registration'=>'0','coode_say'=>'0','coode_backpwd'=>'0','coode_api_name'=>'login.lg->*->Bsphp演示程序|
re.lg->123456789|Bsphp演示程序|','charset_1'=>'1','charset_a'=>'1','charset_aa'=>'1','fontsize'=>'20','codelen'=>'4','width'=>'130','height'=>'45','font'=>'1elephant.ttf','back_color'=>'-1','fontcolor_text'=>'-1','text_r'=>'1','createLine_a'=>'1','createLine_b'=>'1',);?>
