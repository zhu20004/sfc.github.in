<?php
 return array('pay_config'=>'','pay_alipay_set'=>'1','pay_alipay_list'=>'1','pay_alipay_id'=>'1','pay_alipay_key'=>'2','pay_alipay_user'=>'3','pay_post_config'=>'',);?>
