<?php
 return array('pay_config'=>'','pay_chinabank_set'=>'1','pay_chinabank_id'=>'11111111111111111','pay_chinabank_key'=>'333333333333333333','pay_post_config'=>'',);?>
