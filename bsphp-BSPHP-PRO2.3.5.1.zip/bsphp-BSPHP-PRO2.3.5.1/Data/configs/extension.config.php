<?php
 return array('yaoqing_off'=>'0','yaoqing_jifen'=>'0','yaoqing_today_RenShu'=>'0','you_weizi'=>'1','ticheng_oof'=>'0','ticheng_baifenbi_1'=>'0','ticheng_baifenbi_2'=>'0','ticheng_baifenbi_3'=>'0','ticheng_baifenbi_time'=>'0',);?>
