<?php
 return array('pay_config'=>'','pay_yeepay_set'=>'1','pay_yeepay_id'=>'1111111112','pay_yeepay_key'=>'222222222222223','pay_post_config'=>'',);?>
