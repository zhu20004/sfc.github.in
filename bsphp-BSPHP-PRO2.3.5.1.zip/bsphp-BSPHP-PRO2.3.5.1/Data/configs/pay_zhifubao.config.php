<?php
 return array('pay_config'=>'','pay_zhifubao_set'=>'0','pay_zhifubao_key'=>'key007','pay_zhifubao_user'=>'xiaozhou_cn@foxmail.com','pay_post_config'=>'',);?>
