<?php
 
const   DBHOST = "127.0.0.1:3306";
const   DBUSER = "root";
const   DBPASS = "qq1230";
const   DBTABLE = "bsphpcms7x";
const   DBQIANHUAN = "bsphp_";
?>
