<?php
if(isset($_GET['m'])==false) header('Location: ?m=agent');
const BSPHP_SET='AGENT';
require ('../LibBsphp/Global.Bsphp.Inc.php');
?>